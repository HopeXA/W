# MudaeAutoBot - Replit Setup

## Project Overview
This is a **Discord selfbot** for automating interactions with the Mudae Discord bot game. The bot can automatically roll characters, claim waifus/husbandos, and snipe kakera (in-game currency).

**Current State**: ✅ Fully configured and ready to run with proper credentials

## Recent Changes
- **2025-09-18**: Initial GitHub import setup completed
- Installed Python 3.11 and all required Discord libraries
- Fixed JSON configuration format issues
- Set up security measures for token protection
- Configured workflow to run the bot

## User Preferences
- None specified yet

## Project Architecture

### Key Files
- **launcher.py**: Interactive bot launcher (choose which bot to run)
- **start.py**: Quick start script (runs recommended bot directly)
- **mudae_discord_bot.py**: Main bot file using discord.py (RECOMMENDED)
- **mudaebot3.py**: Alternative bot file using discord.py
- **MudaeAutoBot.py**: Legacy version using discum library
- **Settings_Mudae.json**: Configuration file (requires real Discord token)
- **Settings_Mudae_TEMPLATE.json**: Template for safe configuration sharing
- **SECURITY_SETUP.md**: Detailed setup instructions and security warnings

### Dependencies
- Python 3.11
- discord.py-self: Modern Discord selfbot library
- discum: Legacy Discord API wrapper
- Standard JSON/logging libraries

### Configuration
- Bot requires Discord user token (currently using demo placeholder)
- Channel IDs and Guild IDs need to be configured for target Discord servers
- Supports character name lists, series filtering, and kakera sniping

### How to Start Your Bot

**Option 1: Automatic Start (Recommended)**
- Click the "Run" button in Replit
- The launcher will automatically start the best bot version

**Option 2: Interactive Menu**
- Run `python3 launcher.py` in the terminal
- Choose which bot version to run from the menu

**Option 3: Direct Start**
- Run `python3 start.py` for the recommended bot
- Or run `python3 mudae_discord_bot.py` directly

### Bot Versions Available
- **mudae_discord_bot.py**: ✅ Modern, stable (RECOMMENDED)
- **mudaebot3.py**: Alternative version with discord.py
- **MudaeAutoBot.py**: Legacy version using discum library

### Workflow
- **Start application**: Now runs the bot launcher
- Automatically selects the best working bot version
- Ready for production use with your Discord token

## Security Notes
- Discord user token is required but kept secure
- .gitignore configured to prevent accidental token commits  
- Template files provided for safe configuration sharing
- Users warned about Discord ToS violations with selfbots

## Next Steps for Users
1. Follow SECURITY_SETUP.md to configure Discord token
2. Update channel/guild IDs for target servers
3. Customize character lists and kakera settings
4. Run the workflow to start botting