# 5/26/2023
pokeroll and daily roll

![image](https://github.com/vivinano/MudaeAutoBot/assets/33008397/2f2665b7-fa4e-4a7e-8517-e61860388c08)

waifu roll

![image](https://github.com/vivinano/MudaeAutoBot/assets/33008397/0ffb7aa1-9a4f-4089-a1c8-d9d007004528)

![image](https://github.com/vivinano/MudaeAutoBot/assets/33008397/23a55548-5880-44d4-aba9-a859b077ce15)

roll timer waiting

![image](https://github.com/vivinano/MudaeAutoBot/assets/33008397/586ef4b4-8ca3-49b7-a280-43378435a8b2)



# 2/20/2023

waifu claim

![image](https://user-images.githubusercontent.com/33008397/220013914-f4d89f06-d0d9-458b-a7e2-cc8a70dac1f3.png)

pokeroll

![image](https://user-images.githubusercontent.com/33008397/220014089-e5d62b61-fe3b-45a3-bf23-08e34e113b2e.png)


slash roll / button claim test

![image](https://user-images.githubusercontent.com/33008397/220014425-168b25b6-8c7f-4f46-8f73-8795072d94b2.png)




